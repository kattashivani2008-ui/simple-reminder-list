"""
Streamlit Web User Interface for Simple Reminder List Application — FutureReady Hack.

Provides an interactive, modern web dashboard for managing reminders, tracking overdue/upcoming tasks,
visualizing executive metrics, and triggering system diagnostics.
"""

import os
import sys
from datetime import datetime, date, time
from pathlib import Path
import unittest

import streamlit as st
import pandas as pd

# Add parent directory to sys.path
sys.path.insert(0, str(Path(__file__).resolve().parent))

from src.models import Reminder, Priority, Category, ReminderStatus
from src.storage import ReminderDAO, StorageError
from src.validation import InputValidator, ValidationError
from src.analytics import ReminderAnalytics


# Page configuration
st.set_page_config(
    page_title="Simple Reminder List — Modern Web UI",
    page_icon="⏰",
    layout="wide",
    initial_sidebar_state="expanded"
)


# Helper function to load DAO instance
@st.cache_resource(show_spinner=False)
def get_dao(file_path: str = "data/reminders.json") -> ReminderDAO:
    return ReminderDAO(file_path)


def reload_data(file_path: str = "data/reminders.json"):
    dao = get_dao(file_path)
    return dao.load_all()


def main():
    # Sidebar Setup
    st.sidebar.title("⏰ Simple Reminder List")
    st.sidebar.caption("FutureReady Hack — Zero-Dependency Core + Streamlit Web Interface")

    storage_format = st.sidebar.radio(
        "📁 Storage Backend",
        ["JSON (default)", "CSV"],
        index=0
    )
    db_file = "data/reminders.json" if "JSON" in storage_format else "data/sample_reminders.csv"
    dao = ReminderDAO(db_file)

    menu = st.sidebar.radio(
        "🎯 Navigation Menu",
        [
            "📊 Dashboard & Overview",
            "📋 Task List & Search",
            "➕ Add New Reminder",
            "🚨 Overdue & Urgency Ranking",
            "📄 Reports & Data Export",
            "🧪 System Diagnostics & Settings"
        ]
    )

    reminders = dao.load_all()
    metrics = ReminderAnalytics.generate_summary_metrics(reminders)

    # Global Banner Warning for Overdue Items
    overdue_items = ReminderAnalytics.get_overdue_reminders(reminders)
    if overdue_items:
        st.warning(f"🚨 **Attention:** You have **{len(overdue_items)} overdue** pending item(s)! Check the 'Overdue & Urgency Ranking' tab.")

    # -------------------------------------------------------------------------
    # TAB 1: Dashboard & Overview
    # -------------------------------------------------------------------------
    if menu == "📊 Dashboard & Overview":
        st.title("📊 Executive Dashboard & Task Overview")
        st.markdown("Real-time telemetry and productivity metrics computed by `ReminderAnalytics` engine.")

        # Metric Cards
        col1, col2, col3, col4, col5 = st.columns(5)
        col1.metric("Total Records", metrics["total_records"])
        col2.metric("Pending Tasks", metrics["pending_count"], delta=f"{metrics['overdue_count']} overdue", delta_color="inverse")
        col3.metric("Completed Tasks", metrics["completed_count"])
        col4.metric("Completion Rate", f"{metrics['completion_rate_pct']}%")
        col5.metric("Upcoming (7 Days)", metrics["upcoming_7d_count"])

        st.divider()

        # Visual Charts
        c1, c2 = st.columns(2)
        with c1:
            st.subheader("🏷️ Category Distribution")
            if metrics["category_breakdown"]:
                cat_df = pd.DataFrame(
                    list(metrics["category_breakdown"].items()),
                    columns=["Category", "Count"]
                )
                st.bar_chart(cat_df.set_index("Category"))
            else:
                st.info("No records available to display category breakdown.")

        with c2:
            st.subheader("🔥 Pending Priority Breakdown")
            if metrics["priority_breakdown"]:
                prio_df = pd.DataFrame(
                    list(metrics["priority_breakdown"].items()),
                    columns=["Priority", "Count"]
                )
                st.bar_chart(prio_df.set_index("Priority"))
            else:
                st.info("No pending records available for priority breakdown.")

        st.subheader("⚡ Quick High-Urgency Tasks")
        urgent_items = ReminderAnalytics.rank_by_urgency(reminders)[:5]
        if urgent_items:
            table_data = []
            for r in urgent_items:
                table_data.append({
                    "ID": f"#{r.id}",
                    "Title": r.title,
                    "Category": r.category,
                    "Priority": r.priority,
                    "Due Date": r.due_date,
                    "Overdue": "🚨 OVERDUE" if r.is_overdue() else ("📅 Upcoming" if r.is_upcoming(7) else "Pending")
                })
            st.dataframe(pd.DataFrame(table_data), use_container_width=True)
        else:
            st.success("🎉 All caught up! No pending high-urgency tasks.")

    # -------------------------------------------------------------------------
    # TAB 2: Task List & Search
    # -------------------------------------------------------------------------
    elif menu == "📋 Task List & Search":
        st.title("📋 Reminder Task List")
        st.markdown("Filter, sort, inspect, edit, or complete reminders.")

        # Filter Bar
        f1, f2, f3, f4 = st.columns(4)
        search_kw = f1.text_input("🔍 Search Keyword", placeholder="Search title or description...")
        filter_cat = f2.selectbox("🏷️ Category", ["All"] + [c.value for c in Category])
        filter_prio = f3.selectbox("🔥 Priority", ["All"] + [p.value for p in Priority])
        filter_stat = f4.selectbox("🚦 Status", ["All"] + [s.value for s in ReminderStatus])

        # Apply Filters
        filtered = ReminderAnalytics.filter_reminders(
            reminders,
            keyword=search_kw if search_kw else None,
            category=filter_cat if filter_cat != "All" else None,
            priority=filter_prio if filter_prio != "All" else None,
            status=filter_stat if filter_stat != "All" else None
        )

        st.caption(f"Showing {len(filtered)} of {len(reminders)} records.")

        if not filtered:
            st.info("No reminders match the selected criteria.")
        else:
            for r in filtered:
                with st.expander(f"#{r.id} | **{r.title}** ({r.category}) — Due: `{r.due_date}` | Status: {r.status}"):
                    col_info, col_act = st.columns([3, 1])

                    with col_info:
                        st.markdown(f"**Priority:** `{r.priority}` | **Category:** `{r.category}`")
                        st.markdown(f"**Description:** {r.description or '*No description provided*'}")
                        st.caption(f"Created: {r.created_at} | Completed: {r.completed_at or 'N/A'}")
                        if r.is_overdue():
                            st.error(f"🚨 **OVERDUE** by {abs(r.days_remaining())} day(s)!")
                        elif r.is_upcoming(7):
                            st.info(f"📅 Due in {r.days_remaining()} day(s).")

                    with col_act:
                        if r.status == ReminderStatus.PENDING.value:
                            if st.button("✅ Mark Complete", key=f"complete_{r.id}"):
                                r.status = ReminderStatus.COMPLETED.value
                                r.completed_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                                dao.update(r)
                                st.success("Task completed!")
                                st.rerun()

                        if st.button("🗑️ Delete", key=f"del_{r.id}"):
                            dao.delete(r.id)
                            st.success(f"Deleted #{r.id}")
                            st.rerun()

    # -------------------------------------------------------------------------
    # TAB 3: Add New Reminder
    # -------------------------------------------------------------------------
    elif menu == "➕ Add New Reminder":
        st.title("➕ Create New Reminder")
        st.markdown("Defensive form validated against `InputValidator` business rules.")

        with st.form("add_reminder_form"):
            new_title = st.text_input("Title *", placeholder="e.g. Prepare Quarter Audit Presentation")
            
            c1, c2 = st.columns(2)
            new_cat = c1.selectbox("Category", [c.value for c in Category])
            new_prio = c2.selectbox("Priority", [p.value for p in Priority])

            d1, d2 = st.columns(2)
            due_d = d1.date_input("Due Date", value=date.today())
            due_t = d2.time_input("Due Time", value=time(17, 0))

            new_desc = st.text_area("Description (Optional)", placeholder="Add details, links, or notes...")

            submitted = st.form_submit_button("🚀 Save Reminder", use_container_width=True)

            if submitted:
                try:
                    formatted_date = f"{due_d.strftime('%Y-%m-%d')} {due_t.strftime('%H:%M')}"
                    
                    # Run defensive validations
                    clean_title = InputValidator.validate_title(new_title)
                    clean_cat = InputValidator.validate_category(new_cat)
                    clean_date = InputValidator.validate_date(formatted_date)
                    clean_prio = InputValidator.validate_priority(new_prio)

                    new_rem = Reminder(
                        id=0,
                        title=clean_title,
                        category=clean_cat,
                        due_date=clean_date,
                        priority=clean_prio,
                        description=new_desc,
                        status=ReminderStatus.PENDING.value
                    )
                    saved = dao.add(new_rem)
                    st.success(f"✅ Successfully created Reminder #{saved.id}: '{saved.title}'!")
                    st.balloons()
                except ValidationError as ve:
                    st.error(f"❌ Input Validation Error: {ve}")
                except Exception as e:
                    st.error(f"❌ Storage Error: {e}")

    # -------------------------------------------------------------------------
    # TAB 4: Overdue & Urgency Ranking
    # -------------------------------------------------------------------------
    elif menu == "🚨 Overdue & Urgency Ranking":
        st.title("🚨 Overdue Items & Urgency Engine")
        st.markdown("Items sorted by custom Eisenhower urgency score ($1000 + \\text{overdue hours} + \\text{priority weight}$).")

        st.subheader("🚨 Overdue Pending Items")
        overdue_list = ReminderAnalytics.get_overdue_reminders(reminders)
        if overdue_list:
            od_data = []
            for item in overdue_list:
                od_data.append({
                    "ID": f"#{item.id}",
                    "Title": item.title,
                    "Category": item.category,
                    "Priority": item.priority,
                    "Due Date": item.due_date,
                    "Days Overdue": f"{abs(item.days_remaining())} days"
                })
            st.table(pd.DataFrame(od_data))
        else:
            st.success("🎉 Zero overdue items! All pending tasks are within deadline bounds.")

        st.divider()

        st.subheader("🔥 Full Urgency Ranking Matrix")
        ranked_items = ReminderAnalytics.rank_by_urgency(reminders)
        if ranked_items:
            rk_data = []
            for item in ranked_items:
                rk_data.append({
                    "ID": f"#{item.id}",
                    "Urgency Score": f"{item.urgency_score():.1f}",
                    "Title": item.title,
                    "Category": item.category,
                    "Priority": item.priority,
                    "Due Date": item.due_date,
                    "Status": item.status
                })
            st.dataframe(pd.DataFrame(rk_data), use_container_width=True)

    # -------------------------------------------------------------------------
    # TAB 5: Reports & Data Export
    # -------------------------------------------------------------------------
    elif menu == "📄 Reports & Data Export":
        st.title("📄 Executive Reports & Data Export")
        st.markdown("Export publication-ready Markdown audit summaries and backup datasets.")

        st.subheader("📄 Generate Executive Markdown Audit Report")
        report_path = ReminderAnalytics.export_markdown_report(reminders, "exports/reminder_executive_summary.md")
        
        with open(report_path, "r", encoding="utf-8") as f:
            report_text = f.read()

        st.download_button(
            label="📥 Download Executive Summary (.md)",
            data=report_text,
            file_name="reminder_executive_summary.md",
            mime="text/markdown",
            use_container_width=True
        )

        with st.expander("👁️ Preview Generated Executive Audit Report"):
            st.markdown(report_text)

        st.divider()

        st.subheader("💾 Raw Dataset Exports")
        c_csv, c_json = st.columns(2)

        # CSV Export
        csv_data = pd.DataFrame([r.to_dict() for r in reminders]).to_csv(index=False)
        c_csv.download_button(
            label="📥 Download Reminders CSV",
            data=csv_data,
            file_name="reminders_export.csv",
            mime="text/csv"
        )

        # JSON Backup
        import json
        json_data = json.dumps({"reminders": [r.to_dict() for r in reminders]}, indent=2)
        c_json.download_button(
            label="📥 Download Reminders JSON",
            data=json_data,
            file_name="reminders_export.json",
            mime="application/json"
        )

    # -------------------------------------------------------------------------
    # TAB 6: System Diagnostics & Settings
    # -------------------------------------------------------------------------
    elif menu == "🧪 System Diagnostics & Settings":
        st.title("🧪 System Diagnostics & Maintenance")
        st.markdown("Run automated unit test suite and manage sample datasets.")

        col_seed, col_test = st.columns(2)

        with col_seed:
            st.subheader("🌱 Seed Data Generator")
            st.caption("Reset database with 36 realistic test entries.")
            if st.button("🌱 Re-seed Sample Dataset (36 Records)"):
                from generate_seed_data import generate_seed
                generate_seed()
                st.success("✅ Seed dataset generated!")
                st.rerun()

        with col_test:
            st.subheader("🧪 Run 18-Test Diagnostic Suite")
            st.caption("Executes automated `unittest` suite.")
            if st.button("▶️ Execute Diagnostic Tests"):
                loader = unittest.TestLoader()
                tests_dir = os.path.join(os.path.dirname(__file__), "tests")
                suite = loader.discover(start_dir=tests_dir, pattern="test_*.py")
                
                # Capture test output
                import io
                stream = io.StringIO()
                runner = unittest.TextTestRunner(stream=stream, verbosity=2)
                result = runner.run(suite)
                
                output_str = stream.getvalue()
                if result.wasSuccessful():
                    st.success(f"🎉 All {result.testsRun} diagnostic tests passed successfully! (100% Pass Rate)")
                else:
                    st.error(f"❌ Diagnostic suite failed ({len(result.failures)} failures, {len(result.errors)} errors).")
                
                with st.expander("📜 Detailed Test Execution Output", expanded=True):
                    st.code(output_str)


if __name__ == "__main__":
    main()
